<?php
include 'koneksi.php';

if (isset($_POST['batalkomen']) != 'login') {
    echo "<script>
        alert('Anda belum login')
        location.href='../login.php'
    </script>";
}

if (isset($_POST['batalsuka']) != 'login') {
    echo "<script>
        alert('Anda belum login')
        location.href='../login.php'
    </script>";
}
