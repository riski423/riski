<?php
session_start();
include 'koneksi.php';

$userid = $_SESSION['userid'];
$komentarid = $_POST['komentarid'];

// Simulasikan kondisi, gantilah ini dengan logika bisnis sebenarnya
$deletionCondition = true;

if ($deletionCondition) {
    // Jika kondisi penghapusan terpenuhi, tampilkan konfirmasi penghapusan
    echo "<script>
        var user = confirm('Hapus komentar?');

        if (user) {
            // Pengguna mengonfirmasi, lanjutkan dengan penghapusan
            window.location.href = 'hapuskomentar2.php?komentarid=$komentarid&userid=$userid';
        } else {
            // Pengguna membatalkan, tidak ada tindakan yang dilakukan
            window.location.href='../admin/index.php';
        }
    </script>";
} else {
    // Kondisi penghapusan tidak terpenuhi, tampilkan pesan kesalahan
    echo "<script>
        alert('Bukan akun anda');
        window.location.href='../admin/index.php';
    </script>";
}
