<?php
session_start();
include 'koneksi.php';

$fotoid = $_GET['fotoid'];
$userid = $_SESSION['userid'];

$ceksuka2 = mysqli_query($conn, "SELECT * FROM likekomentar WHERE fotoid='$fotoid' AND userid='$userid'");

if (mysqli_num_rows($ceksuka2) == 1) {
    while ($row = mysqli_fetch_array($ceksuka2)) {
        $likeid = $row['likeid'];
        $query = mysqli_query($conn, "delete from likekomentar where likeid='$likeid'");
        echo "<script>
        location.href='../admin/index.php';
        </script>";
    }
} else {
    $tanggallike = date('Y-m-d');
    $query = mysqli_query($conn, "insert into likekomentar values('','$fotoid','$userid','$tanggallike')");

    echo "<script>
        location.href='../admin/index.php';
    </script>";
}
