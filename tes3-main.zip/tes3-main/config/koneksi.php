<?php
$hostname = "localhost";
$userdb = "root";
$passdb = "";
$namedb = "gallery";

$conn = mysqli_connect($hostname, $userdb, $passdb, $namedb);

// if ($conn) {
//     echo "Terhubung";
// } else {
//     echo "tidak terhubung";
// }
