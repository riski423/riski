<?php
include 'koneksi.php';

$userid = $_GET['userid'];
$komentarid = $_GET['komentarid'];

$sql = mysqli_query($conn, "DELETE FROM komentarfoto WHERE komentarid='$komentarid' AND userid='$userid'");

if (mysqli_affected_rows($conn) > 0) {
    echo "<script>
        alert('Komentar dihapus');
        window.location.href='../admin/index.php';
    </script>";
} else {
    echo "<script>
        alert('Bukan akun anda');
        window.location.href='../admin/index.php';
    </script>";
}
